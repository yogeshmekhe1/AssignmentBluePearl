﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebAPP.Model;

namespace WebAPP.Data
{
    public class WebAPPContext : DbContext
    {
        public WebAPPContext (DbContextOptions<WebAPPContext> options)
            : base(options)
        {
        }

        public DbSet<WebAPP.Model.Customer> Customer { get; set; } = default!;
    }
}
